
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="<?= base_url(); ?>libauth/vendor/jquery/dist/jquery.min.js"></script>
  <script src="<?= base_url(); ?>libauth/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Argon JS -->
  <script src="<?= base_url(); ?>libauth/js/argon.js?v=1.0.0"></script>
</body>

</html>
