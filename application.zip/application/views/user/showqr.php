<html>
<head>
<title><?= $title ?></title>
<head>
<body>
<?php
        echo '<img style="margin-left: 16%; margin-right: 15%; margin-top: 15%; width: 350px; height: 350px" src="'.base_url().'upload/qr_image/'.$qrcode.'">';
?>
</body>
</html>